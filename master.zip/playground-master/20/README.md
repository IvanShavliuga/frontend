# 20. Шапка на гридах и флексах с гэпами и БЭМ

- [Видео](https://youtu.be/OkWwM4yE-V0)
- [Демо](https://pepelsbey.github.io/playground/20/)
