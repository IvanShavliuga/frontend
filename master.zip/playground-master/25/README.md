# 25. Свежий взгляд на Gulp: функции и ES-модули

- [Видео](https://youtu.be/fgJmCevEtL4)
