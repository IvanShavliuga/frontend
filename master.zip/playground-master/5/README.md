# 5. Политех, магический JPEG, ненужная форма и object-fit на SVG

- [Подробнее в видео](https://youtu.be/zjaI-LwqLVU)
- [Живое демо](https://pepelsbey.github.io/playground/5/)
