# 21. Направляющие для адаптивной сетки на градиентах и кастомных свойствах

- [Видео](https://youtu.be/WBrngvT78gw)
- [Демо](https://pepelsbey.github.io/playground/21/)
