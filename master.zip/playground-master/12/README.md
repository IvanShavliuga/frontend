# 12. Как вставить двадцать видео с Ютуба и не скачать слона

- [Подробнее в видео](https://youtu.be/4JS70KB9GS0)
- [Демо: было](https://pepelsbey.github.io/playground/12/before.html)
- [Демо: стало](https://pepelsbey.github.io/playground/12/after.html)
