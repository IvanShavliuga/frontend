# 4. Навигация, дизайнеры и код, актуальность, личинки фронтендера и фреймворки

- [Подробнее в видео](https://youtu.be/y52rtbUeCac)
- [Живое демо](https://pepelsbey.github.io/playground/4/)
