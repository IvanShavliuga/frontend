# 6. Погружение в object-fit: cover с полифилом и без

- [Подробнее в видео](https://youtu.be/aZJMOVpMhtc)
- [Живое демо](https://pepelsbey.github.io/playground/6/)
