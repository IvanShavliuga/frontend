# 8. Кто такие дивелоперы, ручной SVG и волнительное подчёркивание

- [Подробнее в видео](https://youtu.be/Me4j7QeKBCM)
- [Живое демо](https://pepelsbey.github.io/playground/8/)
