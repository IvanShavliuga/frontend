# 24. Адаптивная шапка с выпадающим меню на гридах

- [Видео](https://youtu.be/o7A0e4PkSAQ)
- [Демо](https://pepelsbey.github.io/playground/24/)
