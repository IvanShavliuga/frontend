# 16. Звёздный рейтинг ⭐️⭐️⭐️⭐️⭐️

- [Подробнее в видео](https://youtu.be/EbajTYI-gg8)
- [Демо: простой](https://pepelsbey.github.io/playground/16/plain.html)
- [Демо: современный](https://pepelsbey.github.io/playground/16/modern.html)
- [Демо: фокусный](https://pepelsbey.github.io/playground/16/focus.html)
- [Демо: совместимый](https://pepelsbey.github.io/playground/16/label.html)
