# 19. Кастомные свойства или честный Sass вместо CSS-переменных на PostCSS

- [Видео](https://youtu.be/nbN22yqEgM0)
- [Демо: основа](https://pepelsbey.github.io/playground/19/plain/)
- [Демо: Sass](https://pepelsbey.github.io/playground/19/sass/)
- [Демо: PostCSS](https://pepelsbey.github.io/playground/19/postcss/)
- [Демо: темы](https://pepelsbey.github.io/playground/19/themes/)
