# 10. Skillbox, оптимизация графики, Squoosh и элемент picture

- [Подробнее в видео](https://youtu.be/gHLPBlzGRT8)
- [Живое демо](https://pepelsbey.github.io/playground/10/)
