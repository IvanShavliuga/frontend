# 11. Прототип изоляции стилей для Shower на веб-компонентах

- [Подробнее в видео](https://youtu.be/_FRIRJZYlxU)
- [Демо](https://pepelsbey.github.io/playground/11/)
